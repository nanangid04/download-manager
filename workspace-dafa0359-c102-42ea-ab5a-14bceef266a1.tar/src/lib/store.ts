// URL-based data encoding for shareable download links
// No server-side storage needed - all data is encoded in the URL

export interface AffiliateLinkData {
  url: string; // The affiliate URL
  label: string; // Custom button text (e.g., "Lanjutkan", "Next", etc.)
}

export interface DownloadData {
  n: string; // productName
  a: AffiliateLinkData[]; // affiliateLinks with labels
  d: string; // downloadLink
  t: number; // countdown time in seconds (per link)
}

// Encode download data to base64 string for URL
export function encodeDownloadData(data: DownloadData): string {
  const jsonString = JSON.stringify(data);
  // Use base64url encoding (safe for URLs)
  if (typeof window !== 'undefined') {
    return btoa(unescape(encodeURIComponent(jsonString)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }
  // Server-side encoding
  return Buffer.from(jsonString)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

// Decode download data from base64 string
export function decodeDownloadData(encoded: string): DownloadData | null {
  try {
    // Restore base64 padding
    let base64 = encoded.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }

    let jsonString: string;
    if (typeof window !== 'undefined') {
      jsonString = decodeURIComponent(escape(atob(base64)));
    } else {
      jsonString = Buffer.from(base64, 'base64').toString('utf-8');
    }

    const data = JSON.parse(jsonString);

    // Handle both old format (string array) and new format (object array)
    if (!data.n || !data.a || !Array.isArray(data.a) || !data.d) {
      return null;
    }

    // Convert old format to new format if needed
    if (typeof data.a[0] === 'string') {
      data.a = data.a.map((url: string) => ({
        url,
        label: `Klik Link Affiliate`,
      }));
    }

    // Set default countdown if not provided
    if (!data.t) {
      data.t = 7;
    }

    return data as DownloadData;
  } catch {
    return null;
  }
}

// Legacy support - in-memory store for backward compatibility
export interface DownloadLink {
  id: string;
  productName: string;
  affiliateLinks: string[];
  downloadLink: string;
  createdAt: Date;
  updatedAt: Date;
}

const downloadStore = new Map<string, DownloadLink>();

export function generateId(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export function createDownloadLink(data: {
  productName: string;
  affiliateLinks: string[];
  downloadLink: string;
}): DownloadLink {
  const id = generateId();
  const now = new Date();

  const link: DownloadLink = {
    id,
    productName: data.productName,
    affiliateLinks: data.affiliateLinks,
    downloadLink: data.downloadLink,
    createdAt: now,
    updatedAt: now,
  };

  downloadStore.set(id, link);
  return link;
}

export function getAllDownloadLinks(): DownloadLink[] {
  return Array.from(downloadStore.values()).sort(
    (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
  );
}

export function getDownloadLinkById(id: string): DownloadLink | null {
  return downloadStore.get(id) || null;
}

export function updateDownloadLink(
  id: string,
  data: Partial<Omit<DownloadLink, 'id' | 'createdAt'>>
): DownloadLink | null {
  const existing = downloadStore.get(id);
  if (!existing) return null;

  const updated: DownloadLink = {
    ...existing,
    ...data,
    updatedAt: new Date(),
  };

  downloadStore.set(id, updated);
  return updated;
}

export function deleteDownloadLink(id: string): boolean {
  return downloadStore.delete(id);
}

export function getStoreSize(): number {
  return downloadStore.size;
}
