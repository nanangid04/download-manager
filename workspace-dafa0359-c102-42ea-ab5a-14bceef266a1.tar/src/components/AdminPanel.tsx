'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import {
  Copy,
  Download,
  Plus,
  Check,
  Loader2,
  Minus,
  Link2,
  Clock,
  Edit,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  encodeDownloadData,
  decodeDownloadData,
  type DownloadData,
  type AffiliateLinkData,
} from '@/lib/store';

interface AffiliateLink {
  url: string;
  label: string;
}

interface HistoryItem {
  id: string;
  productName: string;
  affiliateCount: number;
  url: string;
  createdAt: string;
}

export function AdminPanel() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [affiliateCount, setAffiliateCount] = useState(1);
  const [countdownTime, setCountdownTime] = useState(7);
  const [formData, setFormData] = useState({
    productName: '',
    affiliateLinks: [{ url: '', label: 'Lanjutkan' }] as AffiliateLink[],
    downloadLink: '',
  });
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingData, setEditingData] = useState<{
    productName: string;
    affiliateLinks: AffiliateLink[];
    downloadLink: string;
    countdownTime: number;
  } | null>(null);
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const { toast } = useToast();

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('downloadManager_settings');
    if (saved) {
      try {
        const settings = JSON.parse(saved);
        if (settings.countdownTime) {
          setCountdownTime(settings.countdownTime);
        }
        if (settings.defaultLabel) {
          setFormData((prev) => ({
            ...prev,
            affiliateLinks: [{ url: '', label: settings.defaultLabel }],
          }));
        }
      } catch {
        // Ignore errors
      }
    }

    const savedUrl = localStorage.getItem('downloadManager_lastUrl');
    if (savedUrl) {
      setGeneratedUrl(savedUrl);
    }
  }, []);

  // Handle affiliate count change
  const handleAffiliateCountChange = useCallback((count: number) => {
    if (count < 1 || count > 10) return;
    setAffiliateCount(count);
    setFormData((prev) => {
      const newLinks = [...prev.affiliateLinks];
      while (newLinks.length < count) {
        newLinks.push({ url: '', label: 'Lanjutkan' });
      }
      while (newLinks.length > count) {
        newLinks.pop();
      }
      return { ...prev, affiliateLinks: newLinks };
    });
  }, []);

  // Handle affiliate link change
  const handleAffiliateLinkChange = useCallback(
    (index: number, field: 'url' | 'label', value: string) => {
      setFormData((prev) => {
        const newLinks = [...prev.affiliateLinks];
        newLinks[index] = { ...newLinks[index], [field]: value };
        return { ...prev, affiliateLinks: newLinks };
      });
    },
    []
  );

  // Set default labels for all links
  const setDefaultLabels = useCallback((label: string) => {
    setFormData((prev) => ({
      ...prev,
      affiliateLinks: prev.affiliateLinks.map((link) => ({
        ...link,
        label,
      })),
    }));
    localStorage.setItem(
      'downloadManager_settings',
      JSON.stringify({ countdownTime, defaultLabel: label })
    );
  }, [countdownTime]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate all fields
      if (!formData.productName.trim()) {
        toast({
          title: 'Error',
          description: 'Nama produk harus diisi',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      const emptyAffiliateLinks = formData.affiliateLinks.filter(
        (link) => !link.url || link.url.trim() === ''
      );
      if (emptyAffiliateLinks.length > 0) {
        toast({
          title: 'Error',
          description: 'Semua link affiliate harus diisi',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      const emptyLabels = formData.affiliateLinks.filter(
        (link) => !link.label || link.label.trim() === ''
      );
      if (emptyLabels.length > 0) {
        toast({
          title: 'Error',
          description: 'Semua label tombol harus diisi',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      if (!formData.downloadLink.trim()) {
        toast({
          title: 'Error',
          description: 'Link download harus diisi',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      if (countdownTime < 1 || countdownTime > 60) {
        toast({
          title: 'Error',
          description: 'Waktu countdown harus antara 1-60 detik',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      // Validate URLs
      try {
        for (const link of formData.affiliateLinks) {
          new URL(link.url);
        }
        new URL(formData.downloadLink);
      } catch {
        toast({
          title: 'Error',
          description: 'Format link tidak valid',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      // Create download data
      const downloadData: DownloadData = {
        n: formData.productName.trim(),
        a: formData.affiliateLinks.map((l) => ({
          url: l.url.trim(),
          label: l.label.trim() || 'Lanjutkan',
        })) as AffiliateLinkData[],
        d: formData.downloadLink.trim(),
        t: countdownTime,
      };

      // Encode to URL
      const encoded = encodeDownloadData(downloadData);
      const url = `${window.location.origin}/?d=${encoded}`;

      // Save to localStorage for history
      const saved = localStorage.getItem('downloadManager_links');
      let links: HistoryItem[] = [];
      try {
        links = saved ? JSON.parse(saved) : [];
      } catch {
        links = [];
      }
      links.push({
        id: Date.now().toString(),
        productName: formData.productName,
        affiliateCount: formData.affiliateLinks.length,
        url,
        createdAt: new Date().toISOString(),
      });
      // Keep only last 50 links
      if (links.length > 50) {
        links = links.slice(-50);
      }
      localStorage.setItem('downloadManager_links', JSON.stringify(links));
      localStorage.setItem('downloadManager_lastUrl', url);

      // Save settings
      localStorage.setItem(
        'downloadManager_settings',
        JSON.stringify({ countdownTime })
      );

      setGeneratedUrl(url);
      setRefreshKey((k) => k + 1);
      toast({
        title: 'Berhasil',
        description: 'Link download berhasil dibuat!',
      });

      // Reset form
      setFormData({
        productName: '',
        affiliateLinks: [{ url: '', label: 'Lanjutkan' }],
        downloadLink: '',
      });
      setAffiliateCount(1);
    } catch {
      toast({
        title: 'Error',
        description: 'Gagal membuat link',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = async () => {
    if (!generatedUrl) return;
    await navigator.clipboard.writeText(generatedUrl);
    setCopied(true);
    toast({
      title: 'Berhasil',
      description: 'Link berhasil disalin ke clipboard',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  // Handle edit
  const handleEdit = useCallback((index: number, url: string) => {
    // Extract encoded data from URL
    const urlObj = new URL(url);
    const encodedData = urlObj.searchParams.get('d');
    if (!encodedData) {
      toast({
        title: 'Error',
        description: 'Tidak dapat membaca data link',
        variant: 'destructive',
      });
      return;
    }

    const data = decodeDownloadData(encodedData);
    if (!data) {
      toast({
        title: 'Error',
        description: 'Data link tidak valid',
        variant: 'destructive',
      });
      return;
    }

    setEditingIndex(index);
    setEditingData({
      productName: data.n,
      affiliateLinks: data.a.map((a) => ({ url: a.url, label: a.label })),
      downloadLink: data.d,
      countdownTime: data.t,
    });
  }, [toast]);

  // Handle edit affiliate count change
  const handleEditAffiliateCountChange = useCallback((count: number) => {
    if (count < 1 || count > 10) return;
    setEditingData((prev) => {
      if (!prev) return prev;
      const newLinks = [...prev.affiliateLinks];
      while (newLinks.length < count) {
        newLinks.push({ url: '', label: 'Lanjutkan' });
      }
      while (newLinks.length > count) {
        newLinks.pop();
      }
      return { ...prev, affiliateLinks: newLinks };
    });
  }, []);

  // Handle edit affiliate link change
  const handleEditAffiliateLinkChange = useCallback(
    (index: number, field: 'url' | 'label', value: string) => {
      setEditingData((prev) => {
        if (!prev) return prev;
        const newLinks = [...prev.affiliateLinks];
        newLinks[index] = { ...newLinks[index], [field]: value };
        return { ...prev, affiliateLinks: newLinks };
      });
    },
    []
  );

  // Save edit
  const handleSaveEdit = useCallback(() => {
    if (editingIndex === null || !editingData) return;

    // Validate
    if (!editingData.productName.trim()) {
      toast({
        title: 'Error',
        description: 'Nama produk harus diisi',
        variant: 'destructive',
      });
      return;
    }

    const emptyAffiliateLinks = editingData.affiliateLinks.filter(
      (link) => !link.url || link.url.trim() === ''
    );
    if (emptyAffiliateLinks.length > 0) {
      toast({
        title: 'Error',
        description: 'Semua link affiliate harus diisi',
        variant: 'destructive',
      });
      return;
    }

    if (!editingData.downloadLink.trim()) {
      toast({
        title: 'Error',
        description: 'Link download harus diisi',
        variant: 'destructive',
      });
      return;
    }

    // Create new download data
    const downloadData: DownloadData = {
      n: editingData.productName.trim(),
      a: editingData.affiliateLinks.map((l) => ({
        url: l.url.trim(),
        label: l.label.trim() || 'Lanjutkan',
      })) as AffiliateLinkData[],
      d: editingData.downloadLink.trim(),
      t: editingData.countdownTime,
    };

    // Encode to URL
    const encoded = encodeDownloadData(downloadData);
    const url = `${window.location.origin}/?d=${encoded}`;

    // Update localStorage
    const saved = localStorage.getItem('downloadManager_links');
    let links: HistoryItem[] = [];
    try {
      links = saved ? JSON.parse(saved) : [];
    } catch {
      links = [];
    }

    // Calculate actual index (reversed array)
    const actualIndex = links.length - 1 - editingIndex;
    if (actualIndex >= 0 && actualIndex < links.length) {
      links[actualIndex] = {
        ...links[actualIndex],
        productName: editingData.productName,
        affiliateCount: editingData.affiliateLinks.length,
        url,
      };
    }

    localStorage.setItem('downloadManager_links', JSON.stringify(links));
    localStorage.setItem('downloadManager_lastUrl', url);

    setGeneratedUrl(url);
    setRefreshKey((k) => k + 1);
    setEditingIndex(null);
    setEditingData(null);

    toast({
      title: 'Berhasil',
      description: 'Link berhasil diperbarui!',
    });
  }, [editingIndex, editingData, toast]);

  // Handle delete
  const handleDelete = useCallback(() => {
    if (deleteIndex === null) return;

    const saved = localStorage.getItem('downloadManager_links');
    let links: HistoryItem[] = [];
    try {
      links = saved ? JSON.parse(saved) : [];
    } catch {
      links = [];
    }

    // Calculate actual index (reversed array)
    const actualIndex = links.length - 1 - deleteIndex;
    if (actualIndex >= 0 && actualIndex < links.length) {
      links.splice(actualIndex, 1);
    }

    localStorage.setItem('downloadManager_links', JSON.stringify(links));
    setRefreshKey((k) => k + 1);
    setDeleteIndex(null);

    toast({
      title: 'Berhasil',
      description: 'Link berhasil dihapus',
    });
  }, [deleteIndex, toast]);

  // Quick label presets
  const labelPresets = ['Lanjutkan', 'Next', 'Klik Disini', 'Selanjutnya', 'Buka Link'];

  return (
    <div className="dark min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Download Manager</h1>
          <p className="text-gray-400">
            Buat link download dengan sistem multi-klik affiliate
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Form Card */}
          <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Buat Link Download
              </CardTitle>
              <CardDescription className="text-gray-400">
                Isi form untuk generate link yang bisa di-share
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Product Name */}
                <div className="space-y-2">
                  <Label htmlFor="productName" className="text-gray-300">
                    Nama Produk
                  </Label>
                  <Input
                    id="productName"
                    placeholder="Contoh: Software Premium v2.0"
                    value={formData.productName}
                    onChange={(e) =>
                      setFormData({ ...formData, productName: e.target.value })
                    }
                    className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-500 focus:ring-emerald-500 focus:border-emerald-500"
                    required
                  />
                </div>

                {/* Countdown Time */}
                <div className="space-y-2">
                  <Label className="text-gray-300 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Waktu Countdown (per tombol)
                  </Label>
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setCountdownTime(Math.max(1, countdownTime - 1))}
                      disabled={countdownTime <= 1}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="w-16 text-center text-white font-bold text-lg">
                      {countdownTime} detik
                    </span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setCountdownTime(Math.min(60, countdownTime + 1))}
                      disabled={countdownTime >= 60}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500">
                    User harus menunggu {countdownTime} detik sebelum bisa klik setiap tombol
                  </p>
                </div>

                {/* Affiliate Count */}
                <div className="space-y-2">
                  <Label className="text-gray-300">Jumlah Link Affiliate</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleAffiliateCountChange(affiliateCount - 1)}
                      disabled={affiliateCount <= 1}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="w-12 text-center text-white font-bold text-lg">
                      {affiliateCount}
                    </span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleAffiliateCountChange(affiliateCount + 1)}
                      disabled={affiliateCount >= 10}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Quick Label Presets */}
                <div className="space-y-2">
                  <Label className="text-gray-300 text-sm">Label Cepat (untuk semua tombol)</Label>
                  <div className="flex flex-wrap gap-2">
                    {labelPresets.map((preset) => (
                      <Button
                        key={preset}
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => setDefaultLabels(preset)}
                        className="text-xs border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                      >
                        {preset}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Affiliate Links */}
                <div className="space-y-4">
                  <Label className="text-gray-300">
                    Link Affiliate ({affiliateCount} link)
                  </Label>
                  {formData.affiliateLinks.map((link, index) => (
                    <div
                      key={index}
                      className="p-3 bg-gray-900/50 rounded-lg border border-gray-700 space-y-2"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          variant="outline"
                          className="text-amber-400 border-amber-600"
                        >
                          Link {index + 1}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 w-12">URL:</span>
                        <Input
                          type="url"
                          placeholder="https://affiliate-link.com"
                          value={link.url}
                          onChange={(e) =>
                            handleAffiliateLinkChange(index, 'url', e.target.value)
                          }
                          className="flex-1 bg-gray-700/50 border-gray-600 text-white placeholder-gray-500 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                          required
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 w-12">Tombol:</span>
                        <Input
                          type="text"
                          placeholder="Lanjutkan / Next / Klik Disini"
                          value={link.label}
                          onChange={(e) =>
                            handleAffiliateLinkChange(index, 'label', e.target.value)
                          }
                          className="flex-1 bg-gray-700/50 border-gray-600 text-white placeholder-gray-500 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                          required
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Download Link */}
                <div className="space-y-2">
                  <Label htmlFor="downloadLink" className="text-gray-300">
                    Link Download (MediaFire/Google Drive)
                  </Label>
                  <Input
                    id="downloadLink"
                    type="url"
                    placeholder="https://drive.google.com/..."
                    value={formData.downloadLink}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        downloadLink: e.target.value,
                      })
                    }
                    className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-500 focus:ring-emerald-500 focus:border-emerald-500"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Membuat Link...
                    </>
                  ) : (
                    <>
                      <Link2 className="w-4 h-4 mr-2" />
                      Generate Link
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Result Card */}
          <div className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Link2 className="w-5 h-5" />
                  Link Download
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Copy dan share link ini ke customer
                </CardDescription>
              </CardHeader>
              <CardContent>
                {generatedUrl ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-gray-900/50 rounded-lg border border-gray-700">
                      <p className="text-sm text-gray-400 mb-2">URL Download:</p>
                      <code className="block p-3 bg-gray-800 rounded text-emerald-400 text-xs break-all">
                        {generatedUrl}
                      </code>
                    </div>

                    <Button
                      onClick={copyToClipboard}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Tersalin!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Link
                        </>
                      )}
                    </Button>

                    <div className="text-center">
                      <a
                        href={generatedUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-400 hover:text-blue-300 underline"
                      >
                        Preview link di tab baru →
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <Download className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Link akan muncul di sini</p>
                    <p className="text-sm">Isi form dan klik Generate Link</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* History Section */}
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white text-lg">Riwayat Link</CardTitle>
                <CardDescription className="text-gray-400">
                  Link yang pernah dibuat (tersimpan di browser ini)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <HistoryList
                  key={refreshKey}
                  onCopy={(url) => {
                    setGeneratedUrl(url);
                    toast({
                      title: 'Berhasil',
                      description: 'Link dimuat, klik Copy untuk menyalin',
                    });
                  }}
                  onEdit={handleEdit}
                  onDelete={(index) => setDeleteIndex(index)}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editingIndex !== null} onOpenChange={() => setEditingIndex(null)}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Link</DialogTitle>
            <DialogDescription className="text-gray-400">
              Perbarui informasi link download
            </DialogDescription>
          </DialogHeader>
          {editingData && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Nama Produk</Label>
                <Input
                  value={editingData.productName}
                  onChange={(e) =>
                    setEditingData({ ...editingData, productName: e.target.value })
                  }
                  className="bg-gray-700/50 border-gray-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Waktu Countdown
                </Label>
                <div className="flex items-center gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setEditingData({
                        ...editingData,
                        countdownTime: Math.max(1, editingData.countdownTime - 1),
                      })
                    }
                    disabled={editingData.countdownTime <= 1}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-16 text-center text-white font-bold text-lg">
                    {editingData.countdownTime} detik
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setEditingData({
                        ...editingData,
                        countdownTime: Math.min(60, editingData.countdownTime + 1),
                      })
                    }
                    disabled={editingData.countdownTime >= 60}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Jumlah Link Affiliate</Label>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      handleEditAffiliateCountChange(editingData.affiliateLinks.length - 1)
                    }
                    disabled={editingData.affiliateLinks.length <= 1}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-12 text-center text-white font-bold text-lg">
                    {editingData.affiliateLinks.length}
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      handleEditAffiliateCountChange(editingData.affiliateLinks.length + 1)
                    }
                    disabled={editingData.affiliateLinks.length >= 10}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-gray-300">Link Affiliate</Label>
                {editingData.affiliateLinks.map((link, index) => (
                  <div
                    key={index}
                    className="p-3 bg-gray-900/50 rounded-lg border border-gray-700 space-y-2"
                  >
                    <Badge
                      variant="outline"
                      className="text-amber-400 border-amber-600"
                    >
                      Link {index + 1}
                    </Badge>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500 w-12">URL:</span>
                      <Input
                        type="url"
                        value={link.url}
                        onChange={(e) =>
                          handleEditAffiliateLinkChange(index, 'url', e.target.value)
                        }
                        className="flex-1 bg-gray-700/50 border-gray-600 text-white text-sm"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500 w-12">Tombol:</span>
                      <Input
                        type="text"
                        value={link.label}
                        onChange={(e) =>
                          handleEditAffiliateLinkChange(index, 'label', e.target.value)
                        }
                        className="flex-1 bg-gray-700/50 border-gray-600 text-white text-sm"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Link Download</Label>
                <Input
                  value={editingData.downloadLink}
                  onChange={(e) =>
                    setEditingData({ ...editingData, downloadLink: e.target.value })
                  }
                  className="bg-gray-700/50 border-gray-600 text-white"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEditingIndex(null)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Batal
            </Button>
            <Button
              onClick={handleSaveEdit}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              Simpan Perubahan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteIndex !== null} onOpenChange={() => setDeleteIndex(null)}>
        <AlertDialogContent className="bg-gray-800 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Hapus Link?</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Tindakan ini tidak dapat dibatalkan. Link akan dihapus secara permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-gray-600 text-gray-300 hover:bg-gray-700">
              Batal
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// History List Component
function HistoryList({
  onCopy,
  onEdit,
  onDelete,
}: {
  onCopy: (url: string) => void;
  onEdit: (index: number, url: string) => void;
  onDelete: (index: number) => void;
}) {
  const links = useMemo(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('downloadManager_links');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed.reverse() : [];
      } catch {
        return [];
      }
    }
    return [];
  }, []);

  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (index: number, url: string) => {
    onCopy(url);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (links.length === 0) {
    return (
      <p className="text-center text-gray-500 py-4">Belum ada riwayat link</p>
    );
  }

  return (
    <div className="space-y-2 max-h-80 overflow-y-auto">
      {links.slice(0, 20).map((link: HistoryItem, index: number) => (
        <div
          key={link.id || index}
          className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg"
        >
          <div className="flex-1 min-w-0">
            <p className="text-white font-medium truncate">{link.productName}</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge
                variant="outline"
                className="text-xs text-amber-400 border-amber-600"
              >
                {link.affiliateCount} affiliate
              </Badge>
              <span className="text-xs text-gray-500">
                {new Date(link.createdAt).toLocaleDateString('id-ID')}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => handleCopy(index, link.url)}
              className="text-gray-400 hover:text-white hover:bg-gray-700"
              title="Copy link"
            >
              {copiedIndex === index ? (
                <Check className="w-4 h-4 text-emerald-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onEdit(index, link.url)}
              className="text-gray-400 hover:text-amber-400 hover:bg-gray-700"
              title="Edit"
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(index)}
              className="text-gray-400 hover:text-red-400 hover:bg-gray-700"
              title="Hapus"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => window.open(link.url, '_blank')}
              className="text-gray-400 hover:text-blue-400 hover:bg-gray-700"
              title="Buka link"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
