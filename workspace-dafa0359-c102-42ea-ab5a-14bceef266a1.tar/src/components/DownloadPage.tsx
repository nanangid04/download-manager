'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Download,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileArchive,
  Gift,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { decodeDownloadData, type DownloadData } from '@/lib/store';

interface DownloadPageProps {
  encodedData: string;
}

export function DownloadPage({ encodedData }: DownloadPageProps) {
  // Decode link data from URL
  const link = useMemo(() => {
    if (!encodedData) return null;
    return decodeDownloadData(encodedData);
  }, [encodedData]);

  if (!link) {
    return <ErrorState error="Link tidak valid atau sudah rusak" />;
  }

  return <DownloadContent link={link} />;
}

// Error State Component
function ErrorState({ error }: { error: string }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800/50 border-gray-700 backdrop-blur-sm">
        <CardContent className="flex flex-col items-center py-12">
          <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Link Tidak Valid</h2>
          <p className="text-gray-400 text-center mb-6">{error}</p>
          <Button
            onClick={() => (window.location.href = '/')}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            Kembali ke Beranda
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// Main Download Content Component
function DownloadContent({ link }: { link: DownloadData }) {
  const initialCountdown = link.t;
  const totalAffiliates = link.a.length;

  const [currentStep, setCurrentStep] = useState(0);
  const [countdown, setCountdown] = useState(initialCountdown);
  const [clickedAffiliates, setClickedAffiliates] = useState<boolean[]>(
    () => new Array(totalAffiliates).fill(false)
  );

  const isCountdownComplete = countdown <= 0;
  const allAffiliatesClicked = clickedAffiliates.every(Boolean);

  const { toast } = useToast();
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Countdown timer using interval
  useEffect(() => {
    // Clear any existing timer
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    // Don't start timer if countdown is complete
    if (countdown <= 0) return;

    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current);
            timerRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [countdown]);

  // Handle affiliate click
  const handleAffiliateClick = useCallback(
    (index: number) => {
      if (clickedAffiliates[index]) return;

      // Open affiliate link in new tab
      window.open(link.a[index].url, '_blank');

      const newClickedAffiliates = [...clickedAffiliates];
      newClickedAffiliates[index] = true;
      setClickedAffiliates(newClickedAffiliates);

      toast({
        title: `Link ${index + 1} Dibuka`,
        description:
          index < totalAffiliates - 1
            ? `Klik link berikutnya (${index + 2}/${totalAffiliates})`
            : 'Klik tombol download untuk mulai download',
      });

      // Start countdown for next step
      if (index < totalAffiliates - 1) {
        setCurrentStep(index + 2);
        setCountdown(initialCountdown);
      } else {
        setCurrentStep(totalAffiliates + 1);
      }
    },
    [link, clickedAffiliates, totalAffiliates, initialCountdown, toast]
  );

  // Handle download click
  const handleDownloadClick = useCallback(() => {
    window.open(link.d, '_blank');
    toast({
      title: 'Download Dimulai',
      description: 'Link download telah dibuka di tab baru',
    });
  }, [link, toast]);

  // Get current step info
  const getCurrentStepInfo = useCallback(() => {
    if (currentStep === 0) {
      return {
        title: 'Mulai',
        affiliateIndex: -1,
      };
    } else if (currentStep <= totalAffiliates) {
      return {
        title: `Link ${currentStep}`,
        affiliateIndex: currentStep - 1,
      };
    } else {
      return {
        title: 'Download',
        affiliateIndex: -1,
      };
    }
  }, [currentStep, totalAffiliates]);

  const stepInfo = getCurrentStepInfo();

  // Calculate progress percentage for current countdown
  const progressPercent = ((initialCountdown - countdown) / initialCountdown) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-6">
          <Badge
            variant="outline"
            className="mb-4 text-emerald-400 border-emerald-600 bg-emerald-600/10"
          >
            <FileArchive className="w-3 h-3 mr-1" />
            Download File
          </Badge>
          <h1 className="text-3xl font-bold text-white mb-2">{link.n}</h1>
          <p className="text-gray-400">
            Klik tombol di bawah untuk memulai download
          </p>
        </div>

        {/* Main Card */}
        <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden">
          {/* Timer Progress Bar */}
          {!isCountdownComplete && currentStep <= totalAffiliates && (
            <div className="relative">
              <Progress
                value={progressPercent}
                className="h-2 rounded-none bg-gray-700"
              />
              <div
                className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-1000 ease-linear"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          )}

          <CardHeader className="text-center pb-4">
            <div className="relative mx-auto w-32 h-32 mb-4">
              {/* Animated Circle */}
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="58"
                  className="fill-none stroke-gray-700"
                  strokeWidth="8"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="58"
                  className="fill-none stroke-emerald-500 transition-all duration-1000 ease-linear"
                  strokeWidth="8"
                  strokeDasharray={364.4}
                  strokeDashoffset={
                    isCountdownComplete || currentStep > totalAffiliates
                      ? 0
                      : 364.4 * (1 - progressPercent / 100)
                  }
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                {isCountdownComplete || currentStep > totalAffiliates ? (
                  <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                ) : (
                  <div className="text-center">
                    <span className="text-4xl font-bold text-white">
                      {countdown}
                    </span>
                    <span className="block text-xs text-gray-400 mt-1">
                      detik
                    </span>
                  </div>
                )}
              </div>
            </div>

            <CardTitle className="text-white text-xl">
              {isCountdownComplete
                ? currentStep > totalAffiliates
                  ? 'Siap Download!'
                  : stepInfo.title
                : 'Mohon Tunggu...'}
            </CardTitle>
            <CardDescription className="text-gray-400">
              {isCountdownComplete
                ? currentStep > totalAffiliates
                  ? 'Klik tombol download untuk mengambil file'
                  : `Klik tombol "${link.a[stepInfo.affiliateIndex]?.label || ''}"`
                : `Tunggu ${countdown} detik untuk melanjutkan`}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Click Status - Show all affiliate steps */}
            <div className="flex flex-wrap justify-center gap-2 mb-4">
              {link.a.map((affiliate, index) => (
                <Badge
                  key={index}
                  variant={clickedAffiliates[index] ? 'default' : 'outline'}
                  className={
                    clickedAffiliates[index]
                      ? 'bg-emerald-600 text-white'
                      : 'text-gray-400 border-gray-600'
                  }
                >
                  {clickedAffiliates[index] ? (
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                  ) : (
                    <Clock className="w-3 h-3 mr-1" />
                  )}
                  {affiliate.label || `Link ${index + 1}`}
                </Badge>
              ))}
              <Badge
                variant={allAffiliatesClicked ? 'default' : 'outline'}
                className={
                  allAffiliatesClicked
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 border-gray-600'
                }
              >
                {allAffiliatesClicked ? (
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                ) : (
                  <Clock className="w-3 h-3 mr-1" />
                )}
                Download
              </Badge>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              {/* Initial state - waiting for first affiliate */}
              {currentStep === 0 && !isCountdownComplete && (
                <Button
                  disabled
                  className="w-full h-14 text-lg font-semibold bg-gray-700 text-gray-500 cursor-not-allowed"
                >
                  <Clock className="w-5 h-5 mr-2 animate-pulse" />
                  Tunggu {countdown} detik...
                </Button>
              )}

              {/* Affiliate buttons */}
              {link.a.map((affiliate, index) => {
                const isCurrentStep =
                  currentStep === index + 1 ||
                  (currentStep === 0 && index === 0 && isCountdownComplete);
                const canClick =
                  isCurrentStep && isCountdownComplete && !clickedAffiliates[index];
                const isWaiting =
                  isCurrentStep && !isCountdownComplete && !clickedAffiliates[index];
                const alreadyClicked = clickedAffiliates[index];
                const notYetAvailable =
                  index > 0 && !clickedAffiliates[index - 1] && !alreadyClicked;

                return (
                  <Button
                    key={index}
                    onClick={() => handleAffiliateClick(index)}
                    disabled={!canClick}
                    className={`w-full h-14 text-lg font-semibold transition-all duration-300 ${
                      alreadyClicked
                        ? 'bg-emerald-700 text-emerald-200 cursor-not-allowed'
                        : notYetAvailable
                        ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                        : isWaiting
                        ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                        : canClick
                        ? 'bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white shadow-lg shadow-amber-500/25'
                        : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {alreadyClicked ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 mr-2" />
                        {affiliate.label} ✓
                      </>
                    ) : isWaiting ? (
                      <>
                        <Clock className="w-5 h-5 mr-2 animate-pulse" />
                        Tunggu {countdown} detik...
                      </>
                    ) : notYetAvailable ? (
                      <>
                        <Clock className="w-5 h-5 mr-2" />
                        {affiliate.label}
                      </>
                    ) : (
                      <>
                        <ExternalLink className="w-5 h-5 mr-2" />
                        {affiliate.label}
                      </>
                    )}
                  </Button>
                );
              })}

              {/* Download button */}
              {allAffiliatesClicked && (
                <Button
                  onClick={handleDownloadClick}
                  className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-lg shadow-blue-500/25"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Download Sekarang
                </Button>
              )}

              {allAffiliatesClicked && (
                <p className="text-center text-sm text-gray-400">
                  <Gift className="w-3 h-3 inline mr-1" />
                  Semua link telah diklik. Download sekarang!
                </p>
              )}
            </div>

            {/* Instructions */}
            <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
              <h3 className="text-sm font-medium text-gray-300 mb-2">
                Instruksi Download:
              </h3>
              <ol className="text-sm text-gray-400 space-y-2 list-decimal list-inside">
                <li>Tunggu countdown selesai</li>
                <li>Klik {link.a.length} tombol secara berurutan</li>
                <li>Klik tombol download untuk mengambil file</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
