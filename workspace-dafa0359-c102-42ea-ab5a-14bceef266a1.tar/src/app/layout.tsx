import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Download Manager - Sistem Download Dua Klik",
  description: "Kelola link download dengan sistem afiliasi dua klik. Mudah, cepat, dan efisien.",
  keywords: ["download", "manager", "afiliasi", "link", "Next.js"],
  authors: [{ name: "Download Manager Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Download Manager",
    description: "Sistem download dengan afiliasi dua klik",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
