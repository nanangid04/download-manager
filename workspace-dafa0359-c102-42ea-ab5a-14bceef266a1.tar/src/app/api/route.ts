import { NextRequest, NextResponse } from "next/server";
import {
  createDownloadLink,
  getAllDownloadLinks,
} from "@/lib/store";

// GET - Get all download links
export async function GET() {
  try {
    const links = getAllDownloadLinks();
    return NextResponse.json({ success: true, data: links });
  } catch (error) {
    console.error("Error fetching links:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengambil data link" },
      { status: 500 }
    );
  }
}

// POST - Create new download link
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productName, affiliateLinks, downloadLink } = body;

    // Validation
    if (!productName || !affiliateLinks || !downloadLink) {
      return NextResponse.json(
        { success: false, error: "Semua field harus diisi" },
        { status: 400 }
      );
    }

    // Validate affiliateLinks is an array with at least 1 item
    if (!Array.isArray(affiliateLinks) || affiliateLinks.length === 0) {
      return NextResponse.json(
        { success: false, error: "Minimal 1 link afiliasi harus diisi" },
        { status: 400 }
      );
    }

    // Validate all affiliate links are filled
    const emptyAffiliateLinks = affiliateLinks.filter((link: string) => !link || link.trim() === '');
    if (emptyAffiliateLinks.length > 0) {
      return NextResponse.json(
        { success: false, error: "Semua link afiliasi harus diisi" },
        { status: 400 }
      );
    }

    // Validate URLs
    try {
      for (const link of affiliateLinks) {
        new URL(link);
      }
      new URL(downloadLink);
    } catch {
      return NextResponse.json(
        { success: false, error: "Format link tidak valid" },
        { status: 400 }
      );
    }

    const newLink = createDownloadLink({
      productName,
      affiliateLinks,
      downloadLink,
    });

    return NextResponse.json({ success: true, data: newLink });
  } catch (error) {
    console.error("Error creating link:", error);
    return NextResponse.json(
      { success: false, error: "Gagal membuat link baru" },
      { status: 500 }
    );
  }
}
