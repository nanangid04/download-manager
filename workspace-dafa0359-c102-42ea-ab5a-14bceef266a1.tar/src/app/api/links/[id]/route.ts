import { NextRequest, NextResponse } from "next/server";
import {
  getDownloadLinkById,
  updateDownloadLink,
  deleteDownloadLink,
} from "@/lib/store";

// GET - Get single download link by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const link = getDownloadLinkById(id);

    if (!link) {
      return NextResponse.json(
        { success: false, error: "Link tidak ditemukan" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: link });
  } catch (error) {
    console.error("Error fetching link:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengambil data link" },
      { status: 500 }
    );
  }
}

// PUT - Update download link
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { productName, affiliateLinks, downloadLink } = body;

    // Check if link exists
    const existing = getDownloadLinkById(id);
    if (!existing) {
      return NextResponse.json(
        { success: false, error: "Link tidak ditemukan" },
        { status: 404 }
      );
    }

    // Validate affiliateLinks if provided
    if (affiliateLinks) {
      if (!Array.isArray(affiliateLinks) || affiliateLinks.length === 0) {
        return NextResponse.json(
          { success: false, error: "Minimal 1 link afiliasi harus diisi" },
          { status: 400 }
        );
      }

      const emptyAffiliateLinks = affiliateLinks.filter((link: string) => !link || link.trim() === '');
      if (emptyAffiliateLinks.length > 0) {
        return NextResponse.json(
          { success: false, error: "Semua link afiliasi harus diisi" },
          { status: 400 }
        );
      }

      try {
        for (const link of affiliateLinks) {
          new URL(link);
        }
      } catch {
        return NextResponse.json(
          { success: false, error: "Format link afiliasi tidak valid" },
          { status: 400 }
        );
      }
    }

    // Validate download link if provided
    if (downloadLink) {
      try {
        new URL(downloadLink);
      } catch {
        return NextResponse.json(
          { success: false, error: "Format link download tidak valid" },
          { status: 400 }
        );
      }
    }

    const updated = updateDownloadLink(id, {
      productName,
      affiliateLinks,
      downloadLink,
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error("Error updating link:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengupdate link" },
      { status: 500 }
    );
  }
}

// DELETE - Delete download link
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const deleted = deleteDownloadLink(id);

    if (!deleted) {
      return NextResponse.json(
        { success: false, error: "Link tidak ditemukan" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Link berhasil dihapus",
    });
  } catch (error) {
    console.error("Error deleting link:", error);
    return NextResponse.json(
      { success: false, error: "Gagal menghapus link" },
      { status: 500 }
    );
  }
}
