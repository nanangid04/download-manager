'use client';

import { useSearchParams } from 'next/navigation';
import { Suspense } from 'react';
import { AdminPanel } from '@/components/AdminPanel';
import { DownloadPage } from '@/components/DownloadPage';
import { Loader2 } from 'lucide-react';

function PageContent() {
  const searchParams = useSearchParams();

  // Check for URL format: ?d=<encoded-data>
  const encodedData = searchParams.get('d');
  if (encodedData) {
    return <DownloadPage encodedData={encodedData} />;
  }

  // Check for legacy URL format: ?download=<id>
  const downloadId = searchParams.get('download');
  if (downloadId) {
    // Show message that old format is no longer supported
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            Link Lama Tidak Didukung
          </h2>
          <p className="text-gray-400 mb-6">
            Format link sudah diperbarui. Silakan minta link baru dari admin.
          </p>
          <a
            href="/"
            className="inline-block px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors"
          >
            Kembali ke Beranda
          </a>
        </div>
      </div>
    );
  }

  // Show admin panel
  return <AdminPanel />;
}

export default function Home() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
        </div>
      }
    >
      <PageContent />
    </Suspense>
  );
}
